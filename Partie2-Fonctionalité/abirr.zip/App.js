// React Native Navigation Drawer – Example using Latest Navigation Version //
// https://aboutreact.com/react-native-navigation-drawer //
import 'react-native-gesture-handler';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Container, Header, Left, Body, Right } from 'native-base';


import * as React from 'react';
import { Button, View, Text , TextInput ,StyleSheet ,ScrollView , SafeAreaView } from 'react-native';


import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createDrawerNavigator, DrawerContentScrollView } from '@react-navigation/drawer';

import FirstPage from './pages/FirstPage';
// import SecondPage from './pages/SecondPage';
// import ThirdPage from './pages/ThirdPage';
import Drawer_nav from './Components/Drawer_nav';
// import Tab_nav from './Components/Tab_nav';
// import InvitationPage from './pages/InvitationPage';



// function App() {
//   return (
      
//     <Drawer_nav/>
  
//   );
// }

// export default App;


import axios from 'axios' ; 

function HomeScreen({ navigation }) {
  return (
    <View style={{ flex: 1,  }} >

      <Text style={ {fontSize : 30 , textAlign: 'center' , margin :10, justifyContent : 'center' ,alignItems : 'center' ,   }}>
      Bienvenue </Text>
      <Text > Nom d'utilisateur  :</Text>
      <TextInput  placeholder="Ecrire votre  Name" 
      style = {{width:'90%' , backgroundColor : '#fffafa' , padding: 15 , marginBottom : 10 
  }}
       />
       <Text > Password :</Text>
      <TextInput  placeholder="Ecrire votre  Password" 
       style = {{width:'90%' , backgroundColor : '#fffafa' , padding: 15 , marginBottom : 10 ,justifyContent : 'center' ,alignItems : 'center'}}      
      secureTextEntry={true} />

      <Button style={styles.btn }
        title="Login"  
        onPress={() => navigation.navigate('Drawer_nav')}
      />
      <Text></Text>
       <Button style={styles.btn}
        title="Sign up" onPress={() => navigation.push('Sign')} />
         <Text></Text>
      <Button style={styles.btn}
        title="Mot de passe oublié ?" onPress={() => navigation.push('Mot de passe oublié')} />
     <Text></Text>
      <Button style={styles.btn}
        title="Version Profesionnel" onPress={() => navigation.push('Version professionel')} />
        <Text></Text>
      <Button style={styles.btn}
        title="Version Personnel" onPress={() => navigation.push('Version personnel')} />  


    </View>
  );
}


class SignScreen extends React.Component   {
 constructor(props ){
   super(props)
  this.state = {
    Name : '' ,
    Password : '',
    Email : ''
  }; } 
  render() { 
  return ( 
     
    <View style={{ flex: 1,  }} >
      <Text style={ {fontSize : 30 , textAlign : 'center' ,  margin :10, }}
      >Sign up Now </Text>
      <Text > Nom d'utilisateur :</Text>
      <TextInput 
       placeholder="ecrire votre nom" 
       style = {{width:'90%' , backgroundColor : '#fffafa' , padding: 15 , marginBottom : 10 }} 
      onChangeText={ (text) => {
        this.setState({Name : text})
      }} />
      <Text > Password :</Text>
      <TextInput  placeholder="ecrire votre Password" 
      style = {{width:'90%' , backgroundColor : '#fffafa' , padding: 15 , marginBottom : 10 }} 
      secureTextEntry={true}
      onChangeText={ (text) => {
        this.setState({Password : text})
      }} />
      <Text > Email :</Text>
      <TextInput 
             placeholder="ecrire votre Email" 
             style = {{width:'90%' , backgroundColor : '#fffafa' , padding: 15 , marginBottom : 10 }} 
       onChangeText={ (text) => {
        this.setState({Email : text})
      }}      />
      

      <Button  title="Ok" 
      onPress={() => {console.log(this.state);
        // fetch('http://192.168.1.12/Verif/', {
        //   method: 'POST',
        //   headers: {
        //     Accept: 'application/json',
        //     'Content-Type': 'application/json'
        //   },
        //   body: JSON.stringify({
        //     Name : this.state.Name, 
        //     Password : this.state.Password,
        //     Email: this.state.Email
        //   })
        //   }).then(responseJson => { 
        //     console.log(responseJson);
        //   }).catch(error => {
        //     console.log(error);
        
        //   });
      axios({
        method : 'post' ,
        url : 'http://192.168.1.12/Verif/' ,
        data : {
        Name : this.state.Name, Password : this.state.Password,Email: this.state.Email
      }}).then(response => { 
        console.log(response.data);
      }).catch(error => {
        console.log(error);
      });
      // this.props.navigation.alert('your  inscription is done')
      // this.props.navigation.navigate('Home')
      }
       } 
        
      />
      <Text></Text>
      {/* <Button title="Go to Home" onPress={() => this.props.navigation.navigate('Home')} />
      <Text></Text> */}

      {/* <Button title="Go back" onPress={() => this.props.navigation.goBack()} />
      <Text></Text> */}
      <Button style={styles.btn}
        title="Version Profesionnel" onPress={() => this.props.navigation.navigate('Version professionel')} />
        <Text></Text>
      <Button style={styles.btn}
        title="Version Personnel" onPress={() =>this.props.navigation.navigate('Version personnel')} />
    </View>
    
  );
}}


function UserScreen({ navigation }) {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }} >
      <Text
       style={ {fontSize : 30 , textAlign: 'center' , margin :10, justifyContent : 'center' ,alignItems : 'center' ,   }}      >
      Congratulations</Text>
    </View>

  );
}


function PassScreen({ navigation }) {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }} >
      <Text
       style={ {fontSize : 30 , textAlign: 'center' , margin :10, justifyContent : 'center' ,alignItems : 'center' ,   }}      >
      Veuiller saisir votre Email :
      </Text> 
      <Text>  </Text>
      <TextInput placeholder=".. "  style = {{width:'90%' , backgroundColor : '#fffafa' , padding: 15 , marginBottom : 10 }} />
      <Button title="Réinitialiser votre mot de passe " onPress={() => navigation.push('Verif')} />

    </View>
  );}

function VerifScreen({ navigation }) {
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }} >
        <Text
         style={ {fontSize : 30 , textAlign: 'center' , margin :10, justifyContent : 'center' ,alignItems : 'center' ,   }}      >
        Vous deviez activer votre compte </Text>
        <Text>Un email a été envoyer sur Testcanada@gmail.com. Merci de verifier votre boite aux lettre</Text>
        <Button title="Verifier " onPress={() => navigation.navigate('')} />
        <Text></Text>
        <Button title="Plus tard " onPress={() => navigation.push('Home')} />


      </View>
    );
}

function PerScreen ({navigation}) {
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }} >
    <Text>Prenom :  </Text>
    <TextInput placeholder="Saisir votre Prenom "/>

    <Text>Nom:  </Text>
    <TextInput placeholder="Saisir votre Nom "/>
    <Text>Date de naissance:  </Text>
    <TextInput placeholder="year/month/day "/>

    <Text>Sexe:  </Text>
    <TextInput placeholder="Saisir votre sexe "/>

    <Text>Cellulaire :  </Text>
    <TextInput placeholder="Saisir votre Cellulaire  "/>

    <Text>Entreprise:  </Text>
    <TextInput placeholder="Saisir votre Entreprise "/>

    <Text>Pays :  </Text>
    <TextInput placeholder="Saisir votre Pays "/>
    <Button title="Créer un compte " />
      
   
    </View>
  )
}

function ProScreen ({navigation}) {
  return (
    <View style = { {  flex : 1 , textAlign : 'center' , justifyContent : 'center' }}>
       <Text style = { {  textAlign : 'center' , fontSize : 25}}> Bienvenue dans la version Profesionnel </Text>
       <Button title="Se Connecter "  onPress = { () => navigation.push('Version professionelle') }/>
       <Text> </Text>
      <Button title="Créer un compte " onPress ={ () => navigation.push('Version personnel')} />
      <Text></Text>
      <Button title="Passer au payement "  onPress = { () => navigation.push('Mode de paiement') }/>
    </View>
  )
}
function ProScreen2 ({navigation}) {
  return (
    <View style = { {  flex : 1 , textAlign : 'center' , justifyContent : 'center' }}>
     
      <Text style={{fontSize : 30 , textAlign: 'center' , margin :10, justifyContent : 'center' ,alignItems : 'center' ,   }}> Welcome </Text>
      <Text style={{fontSize : 15 ,}}> Vous etes maintenant dans la Version professionelle : </Text> 
      <Button title="Suivant" onPress={()=> navigation.push('Chose offer')} /> 
      <Text> Vous pouvez changer a la </Text> 
      <Button title="Version Personnele" color="#D6E4F0" onPress={()=> navigation.push('Version personnel')} /> 

    </View>
 
  )
}
function ChoseScreen ({navigation}) {
  return (
    <View style = { {  flex : 1 , textAlign : 'center' , justifyContent : 'center' }}>   
        <Text style = { {  textAlign : 'center' , fontSize : 25}}> Voici les offres </Text>
    <Button title="Acheter Maintenant " onPress={()=> navigation.push('Obtiens Version professionel')} />
    </View> 
  )
}

function ModeScreen ({navigation}) {
  return (
    <View style = { {  flex : 1 , textAlign : 'center' , justifyContent : 'center' }}> 
      <Text> Nom de titulaire de la carte </Text> 
      <TextInput placeholder="Foulen ben foulen"  />   

      <Text>MM-AA</Text>   
      <TextInput placeholder="..." />

      <Text>CVC</Text>   
      <TextInput placeholder=".." />
      <Text>Code Postal </Text>   
      <TextInput placeholder="ex 5160" />
      <Text>Adresse de courriel</Text>   
      <TextInput placeholder="ex xxx@gmail.com " /> 

      <Button title="Obtenir " onPress={()=> navigation.push('Obtiens Version professionel')} />
    </View> 
  )
}


function PayScreen ({navigation}) {
  return (   
      
      <View style = { {  flex : 1 , textAlign : 'center' , justifyContent : 'center' , alignItems : 'center'}}>
      <Text style = {{ fontSize : 30 }}> Contact </Text> 
      <Text> Email </Text> 
      <TextInput placeholder=" Saisir votre Email" />
      <Text> Pays </Text> 
      <TextInput placeholder=" Saisir votre Pays" /> 
      <Text> Telephone </Text> 
      <TextInput placeholder=" (ex +216 29443379) " />
      <Text> Nous prendrons contact avec vous dans les plus brefs délais.</Text>
      <Button title="Valider" onPress = {() => navigation.navigate.alert('Merci nous avons recu votre confirmation de paiement')} />
    

      </View>
    
    
 
  )
}


const Stack = createStackNavigator();
function App() {
 
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="Sign" component={SignScreen} />
        <Stack.Screen name="User" component={UserScreen} />
        <Stack.Screen name="Mot de passe oublié" component={PassScreen} /> 
        <Stack.Screen name="Verif" component={VerifScreen} /> 
        <Stack.Screen name="Version personnel" component={PerScreen} />
        <Stack.Screen name="Version professionel" component={ProScreen} />  
        <Stack.Screen name="Version professionelle" component={ProScreen2} />  
        <Stack.Screen name="Chose offer" component={ChoseScreen} />          
        <Stack.Screen name="Obtiens Version professionel" component={PayScreen} />  
        <Stack.Screen name="Mode de paiement" component={ModeScreen} />  





      </Stack.Navigator>
    </NavigationContainer>
  );
}



const styles = StyleSheet.create ({
  btn : {
    flexDirection :'row' ,
    justifyContent : 'space-between' ,
    width :'90%'
  }
})



export default App;